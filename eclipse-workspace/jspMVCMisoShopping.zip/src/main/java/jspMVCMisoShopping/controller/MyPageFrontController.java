package jspMVCMisoShopping.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspMVCMisoShopping.service.member.MemberDetailService;
import jspMVCMisoShopping.service.member.MemberUpdateService;

public class MyPageFrontController extends HttpServlet{
	protected void doProcess(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		String requestURI = req.getRequestURI();
		String contextPath = req.getContextPath();
		String command = requestURI.substring(contextPath.length());
		if(command.equals("/memberMyPage.my")) {
			MemberDetailService action = new MemberDetailService();
			action.execute(req);
			RequestDispatcher dispatcher = req.getRequestDispatcher("/myPage/memberMyPage.jsp");
			dispatcher.forward(req, resp);
			System.out.println("memberMyPage.my");
		}
		else if(command.equals("/memberUpdate.my")){
			MemberDetailService action = new MemberDetailService();
			action.execute(req);
			RequestDispatcher dispatcher = req.getRequestDispatcher("/myPage/myModify.jsp");
			dispatcher.forward(req, resp);
		}
		else if(command.equals("/memberModify.my")) {
			MemberUpdateService action = new MemberUpdateService();
			int i = action.execute(req);
			if (i == 1) {
				
				resp.sendRedirect("memberMyPage.my");
			}
			else {
				MemberDetailService action1 = new MemberDetailService();
				action1.execute(req);
				RequestDispatcher dispatcher = req.getRequestDispatcher("/myPage/myModify.jsp");
				dispatcher.forward(req, resp);
			}
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		doProcess(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		doProcess(req, resp);
	}
}
